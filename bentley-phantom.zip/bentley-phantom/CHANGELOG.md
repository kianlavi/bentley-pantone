v0.2 (19 JAN 2014)
- Got rid of partials to fix problems on Ghost v0.4.4

v0.1.0 (5 JAN 2014)
- First Release